-- =============================================================================
-- INVENTORY AND STOCK MANAGEMENT SYSTEM
-- SQL Server Database Setup Script (DatabaseSetup.sql)
-- Compatible with SQL Server Express, LocalDB ((localdb)\MSSQLLocalDB), and Full SQL Server
-- =============================================================================

IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'InventoryManagementDB')
BEGIN
    CREATE DATABASE [InventoryManagementDB];
END
GO

USE [InventoryManagementDB];
GO

-- =============================================================================
-- 1. CATEGORIES TABLE
-- =============================================================================
IF OBJECT_ID('dbo.Categories', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Categories (
        CategoryID   INT IDENTITY(1,1) PRIMARY KEY,
        CategoryName NVARCHAR(100) NOT NULL UNIQUE,
        Description  NVARCHAR(255) NULL,
        CreatedAt    DATETIME NOT NULL DEFAULT GETDATE()
    );
END
GO

-- =============================================================================
-- 2. PRODUCTS TABLE
-- =============================================================================
IF OBJECT_ID('dbo.Products', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Products (
        ProductID       INT IDENTITY(1,1) PRIMARY KEY,
        SKU             NVARCHAR(50) NOT NULL UNIQUE,
        ProductName     NVARCHAR(150) NOT NULL,
        CategoryID      INT NOT NULL,
        UnitPrice       DECIMAL(18,2) NOT NULL CHECK (UnitPrice >= 0),
        QuantityInStock INT NOT NULL DEFAULT 0 CHECK (QuantityInStock >= 0),
        ReorderLevel    INT NOT NULL DEFAULT 10 CHECK (ReorderLevel >= 0),
        SupplierName    NVARCHAR(150) NULL,
        IsActive        BIT NOT NULL DEFAULT 1,
        CreatedAt       DATETIME NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_Products_Categories FOREIGN KEY (CategoryID)
            REFERENCES dbo.Categories(CategoryID)
            ON DELETE NO ACTION
    );
END
GO

-- =============================================================================
-- 3. STOCK TRANSACTIONS TABLE (Audit Trail for Stock-In & Stock-Out)
-- =============================================================================
IF OBJECT_ID('dbo.StockTransactions', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.StockTransactions (
        TransactionID   INT IDENTITY(1,1) PRIMARY KEY,
        ProductID       INT NOT NULL,
        TransactionType NVARCHAR(10) NOT NULL CHECK (TransactionType IN ('IN', 'OUT')),
        Quantity        INT NOT NULL CHECK (Quantity > 0),
        PreviousStock   INT NOT NULL,
        NewStock        INT NOT NULL,
        ReferenceNo     NVARCHAR(100) NULL,
        Remarks         NVARCHAR(255) NULL,
        TransactionDate DATETIME NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_StockTransactions_Products FOREIGN KEY (ProductID)
            REFERENCES dbo.Products(ProductID)
            ON DELETE CASCADE
    );
END
GO
