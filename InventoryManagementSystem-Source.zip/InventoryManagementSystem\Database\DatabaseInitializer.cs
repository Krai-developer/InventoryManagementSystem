using System;
using Microsoft.Data.SqlClient;

namespace InventoryManagementSystem.Database
{
    /// <summary>
    /// Automatically creates the SQL Server database (InventoryManagementDB), tables,
    /// and constraints on first application run.
    /// </summary>
    public static class DatabaseInitializer
    {
        public static bool InitializeDatabase(out string statusMessage)
        {
            try
            {
                // Step 1: Connect to master and create InventoryManagementDB if it does not exist
                using (SqlConnection masterConn = new SqlConnection(DbConnection.GetMasterConnectionString()))
                {
                    masterConn.Open();
                    string checkDbSql = $@"
                        IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'{DbConnection.DatabaseName}')
                        BEGIN
                            CREATE DATABASE [{DbConnection.DatabaseName}];
                        END";

                    using (SqlCommand cmd = new SqlCommand(checkDbSql, masterConn))
                    {
                        cmd.ExecuteNonQuery();
                    }
                }

                // Step 2: Connect to InventoryManagementDB and create tables if missing
                using (SqlConnection conn = DbConnection.GetConnection())
                {
                    conn.Open();

                    string schemaSql = @"
                        -- 1. Categories Table
                        IF OBJECT_ID('dbo.Categories', 'U') IS NULL
                        BEGIN
                            CREATE TABLE dbo.Categories (
                                CategoryID   INT IDENTITY(1,1) PRIMARY KEY,
                                CategoryName NVARCHAR(100) NOT NULL UNIQUE,
                                Description  NVARCHAR(255) NULL,
                                CreatedAt    DATETIME NOT NULL DEFAULT GETDATE()
                            );
                        END

                        -- 2. Products Table
                        IF OBJECT_ID('dbo.Products', 'U') IS NULL
                        BEGIN
                            CREATE TABLE dbo.Products (
                                ProductID       INT IDENTITY(1,1) PRIMARY KEY,
                                SKU             NVARCHAR(50) NOT NULL UNIQUE,
                                ProductName     NVARCHAR(150) NOT NULL,
                                CategoryID      INT NOT NULL,
                                UnitPrice       DECIMAL(18,2) NOT NULL CHECK (UnitPrice >= 0),
                                QuantityInStock INT NOT NULL DEFAULT 0 CHECK (QuantityInStock >= 0),
                                ReorderLevel    INT NOT NULL DEFAULT 10 CHECK (ReorderLevel >= 0),
                                SupplierName    NVARCHAR(150) NULL,
                                IsActive        BIT NOT NULL DEFAULT 1,
                                CreatedAt       DATETIME NOT NULL DEFAULT GETDATE(),
                                CONSTRAINT FK_Products_Categories FOREIGN KEY (CategoryID)
                                    REFERENCES dbo.Categories(CategoryID)
                                    ON DELETE NO ACTION
                            );
                        END

                        -- 3. StockTransactions Table
                        IF OBJECT_ID('dbo.StockTransactions', 'U') IS NULL
                        BEGIN
                            CREATE TABLE dbo.StockTransactions (
                                TransactionID   INT IDENTITY(1,1) PRIMARY KEY,
                                ProductID       INT NOT NULL,
                                TransactionType NVARCHAR(10) NOT NULL CHECK (TransactionType IN ('IN', 'OUT')),
                                Quantity        INT NOT NULL CHECK (Quantity > 0),
                                PreviousStock   INT NOT NULL,
                                NewStock        INT NOT NULL,
                                ReferenceNo     NVARCHAR(100) NULL,
                                Remarks         NVARCHAR(255) NULL,
                                TransactionDate DATETIME NOT NULL DEFAULT GETDATE(),
                                CONSTRAINT FK_StockTransactions_Products FOREIGN KEY (ProductID)
                                    REFERENCES dbo.Products(ProductID)
                                    ON DELETE CASCADE
                            );
                        END

                        -- Remove pre-seeded demo products if they exist
                        IF EXISTS (SELECT 1 FROM dbo.Products WHERE SKU IN (
                            N'CPU-RYZ-9900X', N'CPU-INT-14700K', N'MEM-COR-32DDR5',
                            N'SSD-SAM-990P2T', N'SSD-WD-SN850X1T', N'MON-DEL-U2723QE',
                            N'MON-LG-27GP850', N'PER-LOG-MXM3S', N'PER-KEY-Q1PRO',
                            N'NET-APC-1500VA', N'NET-TP-AXE5400'))
                        BEGIN
                            DELETE FROM dbo.StockTransactions;
                            DELETE FROM dbo.Products;
                            DBCC CHECKIDENT ('dbo.StockTransactions', RESEED, 0);
                            DBCC CHECKIDENT ('dbo.Products', RESEED, 0);
                        END";

                    using (SqlCommand cmd = new SqlCommand(schemaSql, conn))
                    {
                        cmd.ExecuteNonQuery();
                    }
                }

                statusMessage = $"Connected to SQL Server ({DbConnection.ActiveServer})";
                return true;
            }
            catch (Exception ex)
            {
                statusMessage = $"Database connection failed: {ex.Message}";
                return false;
            }
        }

        /// <summary>
        /// Clears all products and stock transactions from the database so the user can start fresh.
        /// </summary>
        public static bool ClearAllProductsAndStock(out string message)
        {
            try
            {
                using (SqlConnection conn = DbConnection.GetConnection())
                {
                    conn.Open();
                    string sql = @"
                        DELETE FROM dbo.StockTransactions;
                        DELETE FROM dbo.Products;
                        DBCC CHECKIDENT ('dbo.StockTransactions', RESEED, 0);
                        DBCC CHECKIDENT ('dbo.Products', RESEED, 0);";

                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.ExecuteNonQuery();
                    }
                }

                message = "All products and stock transactions have been cleared.";
                return true;
            }
            catch (Exception ex)
            {
                message = $"Failed to clear products/stock: {ex.Message}";
                return false;
            }
        }
    }
}
