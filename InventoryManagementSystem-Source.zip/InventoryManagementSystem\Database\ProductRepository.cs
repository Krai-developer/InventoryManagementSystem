using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using InventoryManagementSystem.Models;

namespace InventoryManagementSystem.Database
{
    /// <summary>
    /// ADO.NET Repository for Product Management, Inventory Search, and Low-Stock Alerts.
    /// </summary>
    public class ProductRepository
    {
        /// <summary>
        /// Searches and filters products across ProductID, SKU, ProductName, SupplierName, Category, and Stock Status.
        /// </summary>
        /// <param name="searchKeyword">Text keyword matching ProductID, SKU, ProductName, or SupplierName.</param>
        /// <param name="categoryId">0 for all categories, or a specific CategoryID.</param>
        /// <param name="stockFilter">"ALL", "IN_STOCK", "LOW_STOCK", or "OUT_OF_STOCK"</param>
        public List<Product> SearchProducts(string searchKeyword = "", int categoryId = 0, string stockFilter = "ALL")
        {
            var products = new List<Product>();

            string sql = @"
                SELECT 
                    p.ProductID,
                    p.SKU,
                    p.ProductName,
                    p.CategoryID,
                    c.CategoryName,
                    p.UnitPrice,
                    p.QuantityInStock,
                    p.ReorderLevel,
                    ISNULL(p.SupplierName, N'') AS SupplierName,
                    p.IsActive,
                    p.CreatedAt
                FROM dbo.Products p
                INNER JOIN dbo.Categories c ON p.CategoryID = c.CategoryID
                WHERE p.IsActive = 1
                  AND (@Keyword = N'' 
                       OR CAST(p.ProductID AS NVARCHAR(20)) = @Keyword
                       OR p.SKU LIKE @SearchPattern 
                       OR p.ProductName LIKE @SearchPattern 
                       OR p.SupplierName LIKE @SearchPattern
                       OR c.CategoryName LIKE @SearchPattern)
                  AND (@CategoryID = 0 OR p.CategoryID = @CategoryID)
                  AND (
                        @StockFilter = N'ALL'
                        OR (@StockFilter = N'IN_STOCK' AND p.QuantityInStock > p.ReorderLevel)
                        OR (@StockFilter = N'LOW_STOCK' AND p.QuantityInStock <= p.ReorderLevel)
                        OR (@StockFilter = N'OUT_OF_STOCK' AND p.QuantityInStock = 0)
                      )
                ORDER BY p.ProductName ASC;";

            using (SqlConnection conn = DbConnection.GetConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                string trimmed = (searchKeyword ?? string.Empty).Trim();
                cmd.Parameters.AddWithValue("@Keyword", trimmed);
                cmd.Parameters.AddWithValue("@SearchPattern", $"%{trimmed}%");
                cmd.Parameters.AddWithValue("@CategoryID", categoryId);
                cmd.Parameters.AddWithValue("@StockFilter", stockFilter ?? "ALL");

                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        products.Add(MapProduct(reader));
                    }
                }
            }

            return products;
        }

        /// <summary>
        /// Checks whether a Product SKU / Code already exists in the database.
        /// When updating an existing product, pass its ProductID in excludeProductId.
        /// </summary>
        public bool SkuExists(string sku, int excludeProductId = 0)
        {
            if (string.IsNullOrWhiteSpace(sku))
                return false;

            string sql = @"
                SELECT COUNT(*)
                FROM dbo.Products
                WHERE UPPER(SKU) = @SKU
                  AND ProductID <> @ExcludeID;";

            using (SqlConnection conn = DbConnection.GetConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@SKU", sku.Trim().ToUpperInvariant());
                cmd.Parameters.AddWithValue("@ExcludeID", excludeProductId);

                conn.Open();
                int count = Convert.ToInt32(cmd.ExecuteScalar());
                return count > 0;
            }
        }

        /// <summary>
        /// Retrieves all products that are at or below their ReorderLevel (Low Stock and Out of Stock).
        /// Ordered by lowest stock first for urgent attention.
        /// </summary>
        public List<Product> GetLowStockProducts(int categoryId = 0, bool onlyOutOfStock = false)
        {
            var products = new List<Product>();

            string sql = @"
                SELECT 
                    p.ProductID,
                    p.SKU,
                    p.ProductName,
                    p.CategoryID,
                    c.CategoryName,
                    p.UnitPrice,
                    p.QuantityInStock,
                    p.ReorderLevel,
                    ISNULL(p.SupplierName, N'') AS SupplierName,
                    p.IsActive,
                    p.CreatedAt
                FROM dbo.Products p
                INNER JOIN dbo.Categories c ON p.CategoryID = c.CategoryID
                WHERE p.IsActive = 1
                  AND p.QuantityInStock <= p.ReorderLevel
                  AND (@CategoryID = 0 OR p.CategoryID = @CategoryID)
                  AND (@OnlyOut = 0 OR p.QuantityInStock = 0)
                ORDER BY p.QuantityInStock ASC, (p.ReorderLevel - p.QuantityInStock) DESC;";

            using (SqlConnection conn = DbConnection.GetConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@CategoryID", categoryId);
                cmd.Parameters.AddWithValue("@OnlyOut", onlyOutOfStock ? 1 : 0);

                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        products.Add(MapProduct(reader));
                    }
                }
            }

            return products;
        }

        /// <summary>
        /// Retrieves a single product by its numeric ProductID.
        /// </summary>
        public Product? GetProductById(int productId)
        {
            string sql = @"
                SELECT 
                    p.ProductID,
                    p.SKU,
                    p.ProductName,
                    p.CategoryID,
                    c.CategoryName,
                    p.UnitPrice,
                    p.QuantityInStock,
                    p.ReorderLevel,
                    ISNULL(p.SupplierName, N'') AS SupplierName,
                    p.IsActive,
                    p.CreatedAt
                FROM dbo.Products p
                INNER JOIN dbo.Categories c ON p.CategoryID = c.CategoryID
                WHERE p.ProductID = @ProductID;";

            using (SqlConnection conn = DbConnection.GetConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@ProductID", productId);
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return MapProduct(reader);
                    }
                }
            }

            return null;
        }

        /// <summary>
        /// Retrieves a single product by its SKU code.
        /// </summary>
        public Product? GetProductBySku(string sku)
        {
            if (string.IsNullOrWhiteSpace(sku))
                return null;

            string sql = @"
                SELECT 
                    p.ProductID,
                    p.SKU,
                    p.ProductName,
                    p.CategoryID,
                    c.CategoryName,
                    p.UnitPrice,
                    p.QuantityInStock,
                    p.ReorderLevel,
                    ISNULL(p.SupplierName, N'') AS SupplierName,
                    p.IsActive,
                    p.CreatedAt
                FROM dbo.Products p
                INNER JOIN dbo.Categories c ON p.CategoryID = c.CategoryID
                WHERE UPPER(p.SKU) = @SKU;";

            using (SqlConnection conn = DbConnection.GetConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@SKU", sku.Trim().ToUpperInvariant());
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return MapProduct(reader);
                    }
                }
            }

            return null;
        }

        /// <summary>
        /// Adds a new product and, if QuantityInStock > 0, logs an initial Stock-In transaction atomically.
        /// Validates product business rules and prevents duplicate SKU / Product codes.
        /// </summary>
        public int AddProduct(Product product)
        {
            if (!product.Validate(out string validationError))
            {
                throw new ArgumentException(validationError);
            }

            if (SkuExists(product.SKU))
            {
                throw new InvalidOperationException($"Duplicate Product SKU/ID: A product with SKU '{product.SKU}' already exists in inventory.");
            }

            using (SqlConnection conn = DbConnection.GetConnection())
            {
                conn.Open();
                using (SqlTransaction tx = conn.BeginTransaction())
                {
                    try
                    {
                        string insertSql = @"
                            INSERT INTO dbo.Products 
                                (SKU, ProductName, CategoryID, UnitPrice, QuantityInStock, ReorderLevel, SupplierName, IsActive, CreatedAt)
                            VALUES 
                                (@SKU, @ProductName, @CategoryID, @UnitPrice, @QuantityInStock, @ReorderLevel, @SupplierName, 1, GETDATE());
                            SELECT CAST(SCOPE_IDENTITY() AS INT);";

                        int newProductId;
                        using (SqlCommand cmd = new SqlCommand(insertSql, conn, tx))
                        {
                            cmd.Parameters.AddWithValue("@SKU", product.SKU);
                            cmd.Parameters.AddWithValue("@ProductName", product.ProductName);
                            cmd.Parameters.AddWithValue("@CategoryID", product.CategoryID);
                            cmd.Parameters.AddWithValue("@UnitPrice", product.UnitPrice);
                            cmd.Parameters.AddWithValue("@QuantityInStock", product.QuantityInStock);
                            cmd.Parameters.AddWithValue("@ReorderLevel", product.ReorderLevel);
                            cmd.Parameters.AddWithValue("@SupplierName", string.IsNullOrWhiteSpace(product.SupplierName)
                                ? DBNull.Value
                                : product.SupplierName);

                            newProductId = Convert.ToInt32(cmd.ExecuteScalar());
                        }

                        // If initial stock > 0, record an opening Stock-In audit entry
                        if (product.QuantityInStock > 0)
                        {
                            string logSql = @"
                                INSERT INTO dbo.StockTransactions
                                    (ProductID, TransactionType, Quantity, PreviousStock, NewStock, ReferenceNo, Remarks, TransactionDate)
                                VALUES
                                    (@ProductID, N'IN', @Quantity, 0, @NewStock, N'INIT-STOCK', N'Opening stock on product creation', GETDATE());";

                            using (SqlCommand logCmd = new SqlCommand(logSql, conn, tx))
                            {
                                logCmd.Parameters.AddWithValue("@ProductID", newProductId);
                                logCmd.Parameters.AddWithValue("@Quantity", product.QuantityInStock);
                                logCmd.Parameters.AddWithValue("@NewStock", product.QuantityInStock);
                                logCmd.ExecuteNonQuery();
                            }
                        }

                        tx.Commit();
                        product.ProductID = newProductId;
                        return newProductId;
                    }
                    catch
                    {
                        tx.Rollback();
                        throw;
                    }
                }
            }
        }

        /// <summary>
        /// Updates product details (SKU, Name, Category, UnitPrice, ReorderLevel, Supplier).
        /// Validates product business rules and prevents duplicate SKU codes.
        /// </summary>
        public bool UpdateProduct(Product product)
        {
            if (!product.Validate(out string validationError))
            {
                throw new ArgumentException(validationError);
            }

            if (SkuExists(product.SKU, product.ProductID))
            {
                throw new InvalidOperationException($"Duplicate Product SKU/ID: Another product already uses SKU '{product.SKU}'.");
            }

            string sql = @"
                UPDATE dbo.Products
                SET SKU          = @SKU,
                    ProductName  = @ProductName,
                    CategoryID   = @CategoryID,
                    UnitPrice    = @UnitPrice,
                    ReorderLevel = @ReorderLevel,
                    SupplierName = @SupplierName
                WHERE ProductID  = @ProductID;";

            using (SqlConnection conn = DbConnection.GetConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@ProductID", product.ProductID);
                cmd.Parameters.AddWithValue("@SKU", product.SKU);
                cmd.Parameters.AddWithValue("@ProductName", product.ProductName);
                cmd.Parameters.AddWithValue("@CategoryID", product.CategoryID);
                cmd.Parameters.AddWithValue("@UnitPrice", product.UnitPrice);
                cmd.Parameters.AddWithValue("@ReorderLevel", product.ReorderLevel);
                cmd.Parameters.AddWithValue("@SupplierName", string.IsNullOrWhiteSpace(product.SupplierName)
                    ? DBNull.Value
                    : product.SupplierName);

                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        /// <summary>
        /// Deletes a product record from the database.
        /// </summary>
        public bool DeleteProduct(int productId)
        {
            string sql = "DELETE FROM dbo.Products WHERE ProductID = @ProductID;";

            using (SqlConnection conn = DbConnection.GetConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@ProductID", productId);
                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        private static Product MapProduct(SqlDataReader reader)
        {
            int catId = reader.GetInt32(3);
            string catName = reader.GetString(4);

            return new Product
            {
                ProductID = reader.GetInt32(0),
                SKU = reader.GetString(1),
                ProductName = reader.GetString(2),
                CategoryID = catId,
                CategoryName = catName,
                Category = new Category(catId, catName),
                UnitPrice = reader.GetDecimal(5),
                QuantityInStock = reader.GetInt32(6),
                ReorderLevel = reader.GetInt32(7),
                SupplierName = reader.GetString(8),
                IsActive = reader.GetBoolean(9),
                CreatedAt = reader.GetDateTime(10)
            };
        }
    }
}
