using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;
using InventoryManagementSystem.Database;
using InventoryManagementSystem.Models;
using InventoryManagementSystem.Theme;

namespace InventoryManagementSystem.Forms
{
    public class ProductsForm : UserControl
    {
        private readonly ProductRepository _productRepo = new ProductRepository();
        private readonly CategoryRepository _categoryRepo = new CategoryRepository();
        private readonly Dictionary<int, string> _productImages = new Dictionary<int, string>();

        public event Action? InventoryChanged;
        public event Action<int>? QuickStockInRequested;
        public event Action<int>? QuickStockOutRequested;

        private TextBox _txtSearch = null!;
        private ComboBox _cboFilterCategory = null!;
        private ComboBox _cboFilterStatus = null!;
        private Label _lblResultsCount = null!;

        private DataGridView _dgvProducts = null!;
        private ContextMenuStrip _ctxGridMenu = null!;

        private GroupBox _grpEditor = null!;
        private Label _lblFormMode = null!;
        private int _selectedProductId = 0;
        private TextBox _txtSku = null!;
        private TextBox _txtProductName = null!;
        private ComboBox _cboCategory = null!;
        private NumericUpDown _numUnitPrice = null!;
        private NumericUpDown _numInitialStock = null!;
        private Label _lblInitialStockCaption = null!;
        private NumericUpDown _numReorderLevel = null!;
        private TextBox _txtSupplier = null!;

        private PictureBox _picProductThumb = null!;
        private string _currentImagePath = string.Empty;

        private GradientButton _btnSave = null!;
        private GradientButton _btnDelete = null!;
        private Button _btnClear = null!;
        private Button _btnResetSearch = null!;
        private Button _btnInspect = null!;
        private Button _btnBrowseImage = null!;

        private bool _suppressFilterEvents = false;

        public ProductsForm()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.SupportsTransparentBackColor, true);
            DoubleBuffered = true;
            BackColor = Color.Transparent;
            Dock = DockStyle.Fill;
            Padding = new Padding(18, 14, 18, 16);

            InitializeLayout();
            InitializeContextMenu();
        }

        private void InitializeLayout()
        {
            var rootSplit = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 1,
                BackColor = Color.Transparent
            };
            rootSplit.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            rootSplit.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 368F));

            // Left: Search Bar + Products Grid
            var leftLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 2,
                Margin = new Padding(0, 0, 12, 0),
                BackColor = Color.Transparent
            };
            leftLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 92F));
            leftLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));

            var searchCard = UITheme.CreateCardPanel();
            searchCard.Dock = DockStyle.Fill;
            searchCard.Margin = new Padding(0, 0, 0, 12);

            var lblSearchHeader = new Label
            {
                Text = "Product Inventory",
                Font = UITheme.FontSectionHeader,
                ForeColor = UITheme.TextPrimary,
                BackColor = Color.Transparent,
                Location = new Point(16, 10),
                AutoSize = true
            };

            _lblResultsCount = new Label
            {
                Text = "0 products",
                Font = UITheme.FontSmall,
                ForeColor = UITheme.ElectricBlue,
                BackColor = Color.Transparent,
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
                Location = new Point(searchCard.Width - 150, 12),
                AutoSize = true
            };

            _txtSearch = new TextBox
            {
                PlaceholderText = "Search ID, SKU, or name...",
                Location = new Point(16, 38),
                Size = new Size(205, 27)
            };
            UITheme.StyleTextBox(_txtSearch);
            _txtSearch.TextChanged += (s, e) => ApplyFilters(showNotFoundMessage: false);
            _txtSearch.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter)
                {
                    e.SuppressKeyPress = true;
                    ApplyFilters(showNotFoundMessage: true);
                }
            };

            var btnFind = new GradientButton
            {
                Text = "Search",
                Location = new Point(227, 36),
                Size = new Size(72, 29),
                CornerRadius = 8,
                GradientStart = UITheme.ElectricBlue,
                GradientEnd = UITheme.PrimaryBlue
            };
            btnFind.Click += (s, e) => ApplyFilters(showNotFoundMessage: true);

            _cboFilterCategory = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Location = new Point(306, 38),
                Size = new Size(158, 27)
            };
            UITheme.StyleComboBox(_cboFilterCategory);
            _cboFilterCategory.SelectedIndexChanged += (s, e) => ApplyFilters(showNotFoundMessage: false);

            _cboFilterStatus = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Location = new Point(470, 38),
                Size = new Size(134, 27)
            };
            UITheme.StyleComboBox(_cboFilterStatus);
            _cboFilterStatus.Items.AddRange(new object[]
            {
                "All Statuses",
                "In Stock",
                "Low Stock",
                "Out of Stock"
            });
            _cboFilterStatus.SelectedIndex = 0;
            _cboFilterStatus.SelectedIndexChanged += (s, e) => ApplyFilters(showNotFoundMessage: false);

            _btnResetSearch = new Button
            {
                Text = "Reset",
                Location = new Point(610, 36),
                Size = new Size(64, 29)
            };
            UITheme.StyleSecondaryButton(_btnResetSearch);
            _btnResetSearch.Click += (s, e) =>
            {
                _suppressFilterEvents = true;
                _txtSearch.Clear();
                if (_cboFilterCategory.Items.Count > 0) _cboFilterCategory.SelectedIndex = 0;
                _cboFilterStatus.SelectedIndex = 0;
                _suppressFilterEvents = false;
                ApplyFilters(showNotFoundMessage: false);
            };

            var btnClearAll = new GradientButton
            {
                Text = "Clear All",
                Location = new Point(680, 36),
                Size = new Size(80, 29),
                CornerRadius = 8,
                GradientStart = Color.FromArgb(239, 68, 68),
                GradientEnd = UITheme.DangerRed
            };
            btnClearAll.Click += (s, e) =>
            {
                DialogResult confirm = MessageBox.Show(
                    "Remove all products and stock history from the database?",
                    "Confirm Clear All",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

                if (confirm == DialogResult.Yes)
                {
                    if (DatabaseInitializer.ClearAllProductsAndStock(out string msg))
                    {
                        ApplyFilters(showNotFoundMessage: false);
                        ResetEditorForm();
                        InventoryChanged?.Invoke();
                        MessageBox.Show(msg, "Cleared", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show(msg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            };

            searchCard.Controls.Add(lblSearchHeader);
            searchCard.Controls.Add(_lblResultsCount);
            searchCard.Controls.Add(_txtSearch);
            searchCard.Controls.Add(btnFind);
            searchCard.Controls.Add(_cboFilterCategory);
            searchCard.Controls.Add(_cboFilterStatus);
            searchCard.Controls.Add(_btnResetSearch);
            searchCard.Controls.Add(btnClearAll);

            var gridCard = UITheme.CreateCardPanel();
            gridCard.Dock = DockStyle.Fill;

            var gridFooter = new Panel { Dock = DockStyle.Bottom, Height = 42, Padding = new Padding(0, 6, 0, 0), BackColor = Color.Transparent };
            var lblHint = new Label
            {
                Text = "Select a row to edit, or double-click to inspect product details.",
                Font = UITheme.FontSmall,
                ForeColor = UITheme.TextMuted,
                BackColor = Color.Transparent,
                AutoSize = true,
                Location = new Point(2, 12)
            };

            _btnInspect = new Button
            {
                Text = "View Details",
                Size = new Size(106, 30),
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
                Location = new Point(gridFooter.Width - 344, 6)
            };
            UITheme.StyleSecondaryButton(_btnInspect);
            _btnInspect.Click += (s, e) => OpenProductInspector();

            var btnRowStockIn = new GradientButton
            {
                Text = "Stock In",
                Size = new Size(108, 30),
                CornerRadius = 8,
                GradientStart = UITheme.TealGlow,
                GradientEnd = UITheme.SuccessGreen,
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
                Location = new Point(gridFooter.Width - 230, 6)
            };
            btnRowStockIn.Click += (s, e) =>
            {
                if (_selectedProductId > 0) QuickStockInRequested?.Invoke(_selectedProductId);
                else MessageBox.Show("Select a product from the table first.", "Select Product", MessageBoxButtons.OK, MessageBoxIcon.Information);
            };

            var btnRowStockOut = new GradientButton
            {
                Text = "Stock Out",
                Size = new Size(108, 30),
                CornerRadius = 8,
                GradientStart = Color.FromArgb(245, 158, 11),
                GradientEnd = UITheme.WarningAmber,
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
                Location = new Point(gridFooter.Width - 114, 6)
            };
            btnRowStockOut.Click += (s, e) =>
            {
                if (_selectedProductId > 0) QuickStockOutRequested?.Invoke(_selectedProductId);
                else MessageBox.Show("Select a product from the table first.", "Select Product", MessageBoxButtons.OK, MessageBoxIcon.Information);
            };

            gridFooter.Controls.Add(lblHint);
            gridFooter.Controls.Add(_btnInspect);
            gridFooter.Controls.Add(btnRowStockIn);
            gridFooter.Controls.Add(btnRowStockOut);

            _dgvProducts = new DataGridView { Dock = DockStyle.Fill };
            UITheme.StyleDataGridView(_dgvProducts);
            _dgvProducts.SelectionChanged += DgvProducts_SelectionChanged;
            _dgvProducts.CellPainting += DgvProducts_CellPainting;
            _dgvProducts.CellDoubleClick += (s, e) =>
            {
                if (e.RowIndex >= 0) OpenProductInspector();
            };

            gridCard.Controls.Add(_dgvProducts);
            gridCard.Controls.Add(gridFooter);

            leftLayout.Controls.Add(searchCard, 0, 0);
            leftLayout.Controls.Add(gridCard, 0, 1);

            // Right: Product Editor Card
            var formCard = UITheme.CreateCardPanel(UITheme.ElectricBlue, topTint: true);
            formCard.Dock = DockStyle.Fill;

            _lblFormMode = new Label
            {
                Text = "Add Product",
                Font = UITheme.FontSectionHeader,
                ForeColor = UITheme.TextPrimary,
                BackColor = Color.Transparent,
                Location = new Point(16, 12),
                AutoSize = true
            };
            formCard.Controls.Add(_lblFormMode);

            _grpEditor = new GroupBox
            {
                Text = "Product Information",
                Font = UITheme.FontBold,
                ForeColor = UITheme.TextSecondary,
                BackColor = Color.Transparent,
                Location = new Point(14, 40),
                Size = new Size(340, 480)
            };

            int y = 24;

            _picProductThumb = new PictureBox
            {
                Location = new Point(14, y),
                Size = new Size(56, 56),
                BorderStyle = BorderStyle.FixedSingle,
                SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Color.FromArgb(18, 32, 62)
            };
            RenderDefaultThumb("IMG");
            _grpEditor.Controls.Add(_picProductThumb);

            _btnBrowseImage = new Button
            {
                Text = "Choose Image...",
                Location = new Point(82, y + 4),
                Size = new Size(136, 28)
            };
            UITheme.StyleSecondaryButton(_btnBrowseImage);
            _btnBrowseImage.Click += BtnBrowseImage_Click;
            _grpEditor.Controls.Add(_btnBrowseImage);

            var lblImgHint = new Label
            {
                Text = "Optional product photo",
                Font = UITheme.FontSmall,
                ForeColor = UITheme.TextMuted,
                BackColor = Color.Transparent,
                Location = new Point(82, y + 36),
                AutoSize = true
            };
            _grpEditor.Controls.Add(lblImgHint);
            y += 68;

            _grpEditor.Controls.Add(CreateFieldLabel("SKU / Code *", 14, y));
            var lnkGenSku = new LinkLabel
            {
                Text = "Generate",
                Font = UITheme.FontSmall,
                LinkColor = UITheme.ElectricBlue,
                ActiveLinkColor = Color.White,
                BackColor = Color.Transparent,
                Location = new Point(268, y),
                AutoSize = true
            };
            lnkGenSku.LinkClicked += (s, e) =>
            {
                _txtSku.Text = $"P{Random.Shared.Next(100, 999)}";
            };
            _grpEditor.Controls.Add(lnkGenSku);
            y += 19;

            _txtSku = new TextBox
            {
                Location = new Point(14, y),
                Size = new Size(310, 27),
                PlaceholderText = "e.g., P001"
            };
            UITheme.StyleTextBox(_txtSku);
            _grpEditor.Controls.Add(_txtSku);
            y += 35;

            _grpEditor.Controls.Add(CreateFieldLabel("Product Name *", 14, y));
            y += 19;
            _txtProductName = new TextBox
            {
                Location = new Point(14, y),
                Size = new Size(310, 27),
                PlaceholderText = "Enter product name"
            };
            UITheme.StyleTextBox(_txtProductName);
            _grpEditor.Controls.Add(_txtProductName);
            y += 35;

            _grpEditor.Controls.Add(CreateFieldLabel("Category *", 14, y));
            y += 19;
            _cboCategory = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Location = new Point(14, y),
                Size = new Size(310, 27)
            };
            UITheme.StyleComboBox(_cboCategory);
            _grpEditor.Controls.Add(_cboCategory);
            y += 35;

            _grpEditor.Controls.Add(CreateFieldLabel("Unit Price (₱) *", 14, y));
            y += 19;
            _numUnitPrice = new NumericUpDown
            {
                DecimalPlaces = 2,
                Maximum = 1000000M,
                Minimum = 0M,
                Increment = 5M,
                ThousandsSeparator = true,
                Location = new Point(14, y),
                Size = new Size(310, 27)
            };
            UITheme.StyleNumericUpDown(_numUnitPrice);
            _grpEditor.Controls.Add(_numUnitPrice);
            y += 35;

            _lblInitialStockCaption = CreateFieldLabel("Opening Stock", 14, y);
            _grpEditor.Controls.Add(_lblInitialStockCaption);
            _grpEditor.Controls.Add(CreateFieldLabel("Reorder Level *", 174, y));
            y += 19;

            _numInitialStock = new NumericUpDown
            {
                Maximum = 100000,
                Minimum = 0,
                Location = new Point(14, y),
                Size = new Size(148, 27)
            };
            UITheme.StyleNumericUpDown(_numInitialStock);
            _grpEditor.Controls.Add(_numInitialStock);

            _numReorderLevel = new NumericUpDown
            {
                Maximum = 100000,
                Minimum = 0,
                Value = 10,
                Location = new Point(174, y),
                Size = new Size(150, 27)
            };
            UITheme.StyleNumericUpDown(_numReorderLevel);
            _grpEditor.Controls.Add(_numReorderLevel);
            y += 35;

            _grpEditor.Controls.Add(CreateFieldLabel("Supplier", 14, y));
            y += 19;
            _txtSupplier = new TextBox
            {
                Location = new Point(14, y),
                Size = new Size(310, 27),
                PlaceholderText = "Optional supplier name"
            };
            UITheme.StyleTextBox(_txtSupplier);
            _grpEditor.Controls.Add(_txtSupplier);
            y += 39;

            _btnSave = new GradientButton
            {
                Text = "Save Product",
                Location = new Point(14, y),
                Size = new Size(310, 38),
                CornerRadius = 9,
                GradientStart = UITheme.ElectricBlue,
                GradientEnd = UITheme.PrimaryBlue
            };
            _btnSave.Click += BtnSave_Click;
            _grpEditor.Controls.Add(_btnSave);
            y += 45;

            _btnClear = new Button
            {
                Text = "Clear",
                Location = new Point(14, y),
                Size = new Size(148, 32)
            };
            UITheme.StyleSecondaryButton(_btnClear);
            _btnClear.Click += (s, e) => ResetEditorForm();
            _grpEditor.Controls.Add(_btnClear);

            _btnDelete = new GradientButton
            {
                Text = "Delete",
                Location = new Point(174, y),
                Size = new Size(150, 32),
                CornerRadius = 8,
                GradientStart = Color.FromArgb(239, 68, 68),
                GradientEnd = UITheme.DangerRed,
                Enabled = false
            };
            _btnDelete.Click += BtnDelete_Click;
            _grpEditor.Controls.Add(_btnDelete);

            formCard.Controls.Add(_grpEditor);

            rootSplit.Controls.Add(leftLayout, 0, 0);
            rootSplit.Controls.Add(formCard, 1, 0);
            Controls.Add(rootSplit);
        }

        public void ApplyTheme()
        {
            _lblFormMode.ForeColor = UITheme.TextPrimary;
            _grpEditor.ForeColor = UITheme.TextSecondary;
            UITheme.StyleTextBox(_txtSearch);
            UITheme.StyleComboBox(_cboFilterCategory);
            UITheme.StyleComboBox(_cboFilterStatus);
            UITheme.StyleTextBox(_txtSku);
            UITheme.StyleTextBox(_txtProductName);
            UITheme.StyleComboBox(_cboCategory);
            UITheme.StyleNumericUpDown(_numUnitPrice);
            UITheme.StyleNumericUpDown(_numInitialStock);
            UITheme.StyleNumericUpDown(_numReorderLevel);
            UITheme.StyleTextBox(_txtSupplier);
            UITheme.StyleDataGridView(_dgvProducts);
            UITheme.StyleSecondaryButton(_btnResetSearch);
            UITheme.StyleSecondaryButton(_btnInspect);
            UITheme.StyleSecondaryButton(_btnClear);
            UITheme.StyleSecondaryButton(_btnBrowseImage);
            Invalidate(true);
        }

        private void InitializeContextMenu()
        {
            _ctxGridMenu = new ContextMenuStrip();

            var mnuInspect = new ToolStripMenuItem("View Product Details");
            mnuInspect.Click += (s, e) => OpenProductInspector();

            var mnuStockIn = new ToolStripMenuItem("Stock In");
            mnuStockIn.Click += (s, e) =>
            {
                if (_selectedProductId > 0) QuickStockInRequested?.Invoke(_selectedProductId);
            };

            var mnuStockOut = new ToolStripMenuItem("Stock Out");
            mnuStockOut.Click += (s, e) =>
            {
                if (_selectedProductId > 0) QuickStockOutRequested?.Invoke(_selectedProductId);
            };

            var mnuDelete = new ToolStripMenuItem("Delete Product");
            mnuDelete.ForeColor = UITheme.DangerRed;
            mnuDelete.Click += BtnDelete_Click;

            _ctxGridMenu.Items.Add(mnuInspect);
            _ctxGridMenu.Items.Add(new ToolStripSeparator());
            _ctxGridMenu.Items.Add(mnuStockIn);
            _ctxGridMenu.Items.Add(mnuStockOut);
            _ctxGridMenu.Items.Add(new ToolStripSeparator());
            _ctxGridMenu.Items.Add(mnuDelete);

            _dgvProducts.ContextMenuStrip = _ctxGridMenu;
        }

        private void OpenProductInspector()
        {
            if (_dgvProducts.CurrentRow?.Tag is Product selected)
            {
                if (_productImages.TryGetValue(selected.ProductID, out string? imgPath))
                {
                    selected.ImagePath = imgPath;
                }

                using (var dlg = new ProductDetailsDialog(selected))
                {
                    dlg.ShowDialog(FindForm());
                    if (!string.IsNullOrWhiteSpace(selected.ImagePath))
                    {
                        _productImages[selected.ProductID] = selected.ImagePath;
                        LoadThumbFromFile(selected.ImagePath, selected.SKU);
                    }
                }
            }
            else
            {
                MessageBox.Show("Select a product row first.",
                    "No Product Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnBrowseImage_Click(object? sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Title = "Select Product Photo";
                ofd.Filter = "Image Files (*.png;*.jpg;*.jpeg;*.bmp)|*.png;*.jpg;*.jpeg;*.bmp";
                if (ofd.ShowDialog(FindForm()) == DialogResult.OK)
                {
                    _currentImagePath = ofd.FileName;
                    LoadThumbFromFile(_currentImagePath, _txtSku.Text);
                    if (_selectedProductId > 0)
                    {
                        _productImages[_selectedProductId] = _currentImagePath;
                    }
                }
            }
        }

        private void LoadThumbFromFile(string path, string fallbackLabel)
        {
            if (!string.IsNullOrWhiteSpace(path) && File.Exists(path))
            {
                try
                {
                    using var stream = new FileStream(path, FileMode.Open, FileAccess.Read);
                    _picProductThumb.Image = Image.FromStream(stream);
                    return;
                }
                catch
                {
                }
            }
            RenderDefaultThumb(fallbackLabel);
        }

        private void RenderDefaultThumb(string label)
        {
            Bitmap bmp = new Bitmap(56, 56);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.Clear(Color.FromArgb(18, 32, 62));
                UITheme.DrawIsometricCube(g, new RectangleF(10, 10, 36, 36), glowing: false);
            }
            _picProductThumb.Image = bmp;
        }

        private Label CreateFieldLabel(string text, int x, int y)
        {
            return new Label
            {
                Text = text,
                Font = UITheme.FontBold,
                ForeColor = UITheme.TextSecondary,
                BackColor = Color.Transparent,
                Location = new Point(x, y),
                AutoSize = true
            };
        }

        public void RefreshData(int selectProductId = 0)
        {
            try
            {
                _suppressFilterEvents = true;

                List<Category> categories = _categoryRepo.GetAllCategories();

                int prevFilterCatId = (_cboFilterCategory.SelectedItem as Category)?.CategoryID ?? 0;
                _cboFilterCategory.Items.Clear();
                _cboFilterCategory.Items.Add(new Category(0, "All Categories"));
                foreach (var cat in categories) _cboFilterCategory.Items.Add(cat);
                _cboFilterCategory.SelectedIndex = 0;
                for (int i = 0; i < _cboFilterCategory.Items.Count; i++)
                {
                    if (((Category)_cboFilterCategory.Items[i]!).CategoryID == prevFilterCatId)
                    {
                        _cboFilterCategory.SelectedIndex = i;
                        break;
                    }
                }

                _cboCategory.DataSource = null;
                _cboCategory.DataSource = categories;
                _cboCategory.DisplayMember = "CategoryName";
                _cboCategory.ValueMember = "CategoryID";

                _suppressFilterEvents = false;

                ApplyFilters(showNotFoundMessage: false);

                if (selectProductId > 0)
                {
                    foreach (DataGridViewRow row in _dgvProducts.Rows)
                    {
                        if (row.Tag is Product p && p.ProductID == selectProductId)
                        {
                            row.Selected = true;
                            _dgvProducts.CurrentCell = row.Cells["SKU"];
                            LoadProductIntoEditor(p);
                            return;
                        }
                    }
                }

                ResetEditorForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading products:\n{ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ApplyFilters(bool showNotFoundMessage = false)
        {
            if (_suppressFilterEvents) return;

            string keyword = _txtSearch.Text.Trim();
            int categoryId = (_cboFilterCategory.SelectedItem as Category)?.CategoryID ?? 0;

            string stockFilter = _cboFilterStatus.SelectedIndex switch
            {
                1 => "IN_STOCK",
                2 => "LOW_STOCK",
                3 => "OUT_OF_STOCK",
                _ => "ALL"
            };

            List<Product> products = _productRepo.SearchProducts(keyword, categoryId, stockFilter);

            _dgvProducts.SelectionChanged -= DgvProducts_SelectionChanged;
            _dgvProducts.Rows.Clear();
            _dgvProducts.Columns.Clear();

            _dgvProducts.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ProductID",
                HeaderText = "ID",
                FillWeight = 8,
                DefaultCellStyle = new DataGridViewCellStyle { Alignment = DataGridViewContentAlignment.MiddleCenter }
            });
            _dgvProducts.Columns.Add(new DataGridViewTextBoxColumn { Name = "SKU", HeaderText = "SKU", FillWeight = 16 });
            _dgvProducts.Columns.Add(new DataGridViewTextBoxColumn { Name = "ProductName", HeaderText = "Product Name", FillWeight = 30 });
            _dgvProducts.Columns.Add(new DataGridViewTextBoxColumn { Name = "CategoryName", HeaderText = "Category", FillWeight = 19 });
            _dgvProducts.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "UnitPrice",
                HeaderText = "Price (₱)",
                FillWeight = 14,
                DefaultCellStyle = new DataGridViewCellStyle { Alignment = DataGridViewContentAlignment.MiddleRight }
            });
            _dgvProducts.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "QuantityInStock",
                HeaderText = "Stock",
                FillWeight = 11,
                DefaultCellStyle = new DataGridViewCellStyle { Alignment = DataGridViewContentAlignment.MiddleCenter, Font = UITheme.FontBold }
            });
            _dgvProducts.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ReorderLevel",
                HeaderText = "Min",
                FillWeight = 10,
                DefaultCellStyle = new DataGridViewCellStyle { Alignment = DataGridViewContentAlignment.MiddleCenter }
            });
            _dgvProducts.Columns.Add(new DataGridViewTextBoxColumn { Name = "Status", HeaderText = "Status", FillWeight = 18 });
            _dgvProducts.Columns.Add(new DataGridViewTextBoxColumn { Name = "Supplier", HeaderText = "Supplier", FillWeight = 18 });

            foreach (var p in products)
            {
                int rowIdx = _dgvProducts.Rows.Add(
                    p.ProductID,
                    p.SKU,
                    p.ProductName,
                    p.CategoryName,
                    p.UnitPrice.ToString("N2"),
                    p.QuantityInStock,
                    p.ReorderLevel,
                    p.StockStatus,
                    p.SupplierName);
                _dgvProducts.Rows[rowIdx].Tag = p;
            }

            if (products.Count == 0 && !string.IsNullOrEmpty(keyword))
            {
                _lblResultsCount.Text = $"No results for '{keyword}'";
                _lblResultsCount.ForeColor = UITheme.DangerRed;

                if (showNotFoundMessage)
                {
                    MessageBox.Show($"No product found matching '{keyword}'.",
                        "Product Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                _lblResultsCount.Text = $"{products.Count} product(s)";
                _lblResultsCount.ForeColor = UITheme.ElectricBlue;
            }

            _dgvProducts.ClearSelection();
            _dgvProducts.SelectionChanged += DgvProducts_SelectionChanged;
        }

        private void DgvProducts_SelectionChanged(object? sender, EventArgs e)
        {
            if (_dgvProducts.CurrentRow?.Tag is Product selected)
            {
                LoadProductIntoEditor(selected);
            }
        }

        private void LoadProductIntoEditor(Product selected)
        {
            _selectedProductId = selected.ProductID;
            _lblFormMode.Text = $"Edit Product #{selected.ProductID}";
            _txtSku.Text = selected.SKU;
            _txtProductName.Text = selected.ProductName;
            _cboCategory.SelectedValue = selected.CategoryID;
            _numUnitPrice.Value = selected.UnitPrice;
            _numInitialStock.Value = selected.QuantityInStock;
            _numInitialStock.Enabled = false;
            _lblInitialStockCaption.Text = "Current Stock";
            _numReorderLevel.Value = selected.ReorderLevel;
            _txtSupplier.Text = selected.SupplierName;

            if (_productImages.TryGetValue(selected.ProductID, out string? imgPath))
            {
                _currentImagePath = imgPath;
                LoadThumbFromFile(imgPath, selected.SKU);
            }
            else
            {
                _currentImagePath = string.Empty;
                RenderDefaultThumb(selected.SKU);
            }

            _btnSave.Text = "Update Product";
            _btnDelete.Enabled = true;
        }

        private void ResetEditorForm()
        {
            _selectedProductId = 0;
            _lblFormMode.Text = "Add Product";
            _txtSku.Clear();
            _txtProductName.Clear();
            if (_cboCategory.Items.Count > 0) _cboCategory.SelectedIndex = 0;
            _numUnitPrice.Value = 0M;
            _numInitialStock.Value = 0;
            _numInitialStock.Enabled = true;
            _lblInitialStockCaption.Text = "Opening Stock";
            _numReorderLevel.Value = 10;
            _txtSupplier.Clear();
            _currentImagePath = string.Empty;
            RenderDefaultThumb("IMG");

            _btnSave.Text = "Save Product";
            _btnDelete.Enabled = false;
            _dgvProducts.ClearSelection();
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_txtSku.Text))
            {
                MessageBox.Show("SKU cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                _txtSku.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(_txtProductName.Text))
            {
                MessageBox.Show("Product Name cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                _txtProductName.Focus();
                return;
            }

            if (_cboCategory.SelectedValue == null)
            {
                MessageBox.Show("Please select a category. Add one under Categories first if none exist.",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var product = new Product(
                sku: _txtSku.Text,
                productName: _txtProductName.Text,
                categoryId: Convert.ToInt32(_cboCategory.SelectedValue),
                unitPrice: _numUnitPrice.Value,
                quantityInStock: (int)_numInitialStock.Value,
                reorderLevel: (int)_numReorderLevel.Value,
                supplierName: _txtSupplier.Text)
            {
                ProductID = _selectedProductId,
                ImagePath = _currentImagePath
            };

            if (!product.Validate(out string validationError))
            {
                MessageBox.Show(validationError, "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                if (_productRepo.SkuExists(product.SKU, _selectedProductId))
                {
                    MessageBox.Show($"A product with SKU '{product.SKU}' already exists.",
                        "Duplicate SKU", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    _txtSku.Focus();
                    _txtSku.SelectAll();
                    return;
                }

                if (_selectedProductId == 0)
                {
                    int newId = _productRepo.AddProduct(product);
                    if (!string.IsNullOrWhiteSpace(_currentImagePath))
                        _productImages[newId] = _currentImagePath;

                    MessageBox.Show($"Product '{product.ProductName}' saved.",
                        "Product Added", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    _productRepo.UpdateProduct(product);
                    if (!string.IsNullOrWhiteSpace(_currentImagePath))
                        _productImages[product.ProductID] = _currentImagePath;

                    MessageBox.Show($"Product '{product.ProductName}' updated.",
                        "Product Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                ApplyFilters(showNotFoundMessage: false);
                ResetEditorForm();
                InventoryChanged?.Invoke();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Could not save product:\n{ex.Message}",
                    "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnDelete_Click(object? sender, EventArgs e)
        {
            if (_selectedProductId <= 0)
            {
                MessageBox.Show("Select a product to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DialogResult confirm = MessageBox.Show(
                $"Delete '{_txtProductName.Text}' ({_txtSku.Text})?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (confirm == DialogResult.Yes)
            {
                try
                {
                    _productRepo.DeleteProduct(_selectedProductId);
                    _productImages.Remove(_selectedProductId);
                    ApplyFilters(showNotFoundMessage: false);
                    ResetEditorForm();
                    InventoryChanged?.Invoke();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error deleting product:\n{ex.Message}", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void DgvProducts_CellPainting(object? sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex < 0) return;

            if (_dgvProducts.Columns[e.ColumnIndex].Name == "Status" && e.Value != null)
            {
                UITheme.PaintStatusPillCell(e, e.Value.ToString());
            }
        }
    }
}
