using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using InventoryManagementSystem.Database;
using InventoryManagementSystem.Models;
using InventoryManagementSystem.Theme;

namespace InventoryManagementSystem.Forms
{
    public class ReportsForm : UserControl
    {
        private readonly ProductRepository _productRepo = new ProductRepository();
        private readonly CategoryRepository _categoryRepo = new CategoryRepository();
        private readonly StockTransactionRepository _txRepo = new StockTransactionRepository();

        private RadioButton _rbValuationReport = null!;
        private RadioButton _rbMovementReport = null!;
        private ComboBox _cboCategory = null!;
        private ComboBox _cboMovementType = null!;
        private DateTimePicker _dtpFrom = null!;
        private DateTimePicker _dtpTo = null!;
        private Panel _pnlDateFilters = null!;

        private Label _lblSummaryMetric1 = null!;
        private Label _lblSummaryMetric2 = null!;
        private Label _lblSummaryMetric3 = null!;

        private DataGridView _dgvReport = null!;

        private bool _suppressEvents = false;

        public ReportsForm()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.SupportsTransparentBackColor, true);
            DoubleBuffered = true;
            BackColor = Color.Transparent;
            Dock = DockStyle.Fill;
            Padding = new Padding(18, 14, 18, 16);

            InitializeLayout();
        }

        private void InitializeLayout()
        {
            var mainLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 3,
                BackColor = Color.Transparent
            };
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 114F));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 54F));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));

            var filterCard = UITheme.CreateCardPanel();
            filterCard.Dock = DockStyle.Fill;
            filterCard.Margin = new Padding(0, 0, 0, 12);

            filterCard.Controls.Add(new Label
            {
                Text = "Inventory Reports",
                Font = UITheme.FontSectionHeader,
                ForeColor = UITheme.TextPrimary,
                BackColor = Color.Transparent,
                Location = new Point(16, 10),
                AutoSize = true
            });

            _rbValuationReport = new RadioButton
            {
                Text = "Current Stock & Valuation",
                Font = UITheme.FontBold,
                ForeColor = UITheme.TextSecondary,
                BackColor = Color.Transparent,
                Location = new Point(16, 36),
                Checked = true,
                AutoSize = true
            };
            _rbValuationReport.CheckedChanged += ReportMode_Changed;

            _rbMovementReport = new RadioButton
            {
                Text = "Stock Transaction History",
                Font = UITheme.FontBold,
                ForeColor = UITheme.TextSecondary,
                BackColor = Color.Transparent,
                Location = new Point(250, 36),
                AutoSize = true
            };
            _rbMovementReport.CheckedChanged += ReportMode_Changed;

            filterCard.Controls.Add(new Label
            {
                Text = "Category:",
                Font = UITheme.FontRegular,
                ForeColor = UITheme.TextSecondary,
                BackColor = Color.Transparent,
                Location = new Point(16, 70),
                AutoSize = true
            });

            _cboCategory = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Location = new Point(84, 66),
                Size = new Size(185, 27)
            };
            UITheme.StyleComboBox(_cboCategory);
            _cboCategory.SelectedIndexChanged += (s, e) => GenerateReport();

            _pnlDateFilters = new Panel
            {
                Location = new Point(285, 62),
                Size = new Size(510, 36),
                BackColor = Color.Transparent,
                Visible = false
            };

            _pnlDateFilters.Controls.Add(new Label { Text = "Type:", Font = UITheme.FontRegular, ForeColor = UITheme.TextSecondary, BackColor = Color.Transparent, Location = new Point(0, 8), AutoSize = true });
            _cboMovementType = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Location = new Point(42, 4),
                Size = new Size(100, 27)
            };
            UITheme.StyleComboBox(_cboMovementType);
            _cboMovementType.Items.AddRange(new object[] { "ALL", "IN", "OUT" });
            _cboMovementType.SelectedIndex = 0;
            _cboMovementType.SelectedIndexChanged += (s, e) => GenerateReport();
            _pnlDateFilters.Controls.Add(_cboMovementType);

            _pnlDateFilters.Controls.Add(new Label { Text = "From:", Font = UITheme.FontRegular, ForeColor = UITheme.TextSecondary, BackColor = Color.Transparent, Location = new Point(155, 8), AutoSize = true });
            _dtpFrom = new DateTimePicker
            {
                Format = DateTimePickerFormat.Short,
                Font = UITheme.FontRegular,
                Value = DateTime.Now.AddDays(-30),
                Location = new Point(198, 4),
                Size = new Size(115, 27)
            };
            _dtpFrom.ValueChanged += (s, e) => GenerateReport();
            _pnlDateFilters.Controls.Add(_dtpFrom);

            _pnlDateFilters.Controls.Add(new Label { Text = "To:", Font = UITheme.FontRegular, ForeColor = UITheme.TextSecondary, BackColor = Color.Transparent, Location = new Point(322, 8), AutoSize = true });
            _dtpTo = new DateTimePicker
            {
                Format = DateTimePickerFormat.Short,
                Font = UITheme.FontRegular,
                Value = DateTime.Now,
                Location = new Point(350, 4),
                Size = new Size(115, 27)
            };
            _dtpTo.ValueChanged += (s, e) => GenerateReport();
            _pnlDateFilters.Controls.Add(_dtpTo);

            var btnExportCsv = new GradientButton
            {
                Text = "Export CSV",
                Size = new Size(140, 34),
                CornerRadius = 9,
                GradientStart = UITheme.TealGlow,
                GradientEnd = UITheme.SuccessGreen,
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
                Location = new Point(filterCard.Width - 158, 62)
            };
            btnExportCsv.Click += BtnExportCsv_Click;

            filterCard.Controls.Add(_rbValuationReport);
            filterCard.Controls.Add(_rbMovementReport);
            filterCard.Controls.Add(_cboCategory);
            filterCard.Controls.Add(_pnlDateFilters);
            filterCard.Controls.Add(btnExportCsv);

            var summaryCard = UITheme.CreateCardPanel();
            summaryCard.Dock = DockStyle.Fill;
            summaryCard.Margin = new Padding(0, 0, 0, 12);

            _lblSummaryMetric1 = new Label
            {
                Text = "Products: 0",
                Font = UITheme.FontBold,
                ForeColor = UITheme.TextPrimary,
                BackColor = Color.Transparent,
                Location = new Point(16, 12),
                AutoSize = true
            };

            _lblSummaryMetric2 = new Label
            {
                Text = "Total Units: 0",
                Font = UITheme.FontBold,
                ForeColor = UITheme.ElectricBlue,
                BackColor = Color.Transparent,
                Location = new Point(260, 12),
                AutoSize = true
            };

            _lblSummaryMetric3 = new Label
            {
                Text = "Total Value: ₱0.00",
                Font = UITheme.FontBold,
                ForeColor = UITheme.TealGlow,
                BackColor = Color.Transparent,
                Location = new Point(520, 12),
                AutoSize = true
            };

            summaryCard.Controls.Add(_lblSummaryMetric1);
            summaryCard.Controls.Add(_lblSummaryMetric2);
            summaryCard.Controls.Add(_lblSummaryMetric3);

            var gridCard = UITheme.CreateCardPanel();
            gridCard.Dock = DockStyle.Fill;

            _dgvReport = new DataGridView { Dock = DockStyle.Fill };
            UITheme.StyleDataGridView(_dgvReport);
            _dgvReport.CellPainting += DgvReport_CellPainting;
            _dgvReport.CellFormatting += DgvReport_CellFormatting;

            gridCard.Controls.Add(_dgvReport);

            mainLayout.Controls.Add(filterCard, 0, 0);
            mainLayout.Controls.Add(summaryCard, 0, 1);
            mainLayout.Controls.Add(gridCard, 0, 2);
            Controls.Add(mainLayout);
        }

        public void ApplyTheme()
        {
            _rbValuationReport.ForeColor = UITheme.TextSecondary;
            _rbMovementReport.ForeColor = UITheme.TextSecondary;
            _lblSummaryMetric1.ForeColor = UITheme.TextPrimary;
            UITheme.StyleComboBox(_cboCategory);
            UITheme.StyleComboBox(_cboMovementType);
            UITheme.StyleDataGridView(_dgvReport);
            Invalidate(true);
        }

        public void RefreshData()
        {
            try
            {
                _suppressEvents = true;
                List<Category> categories = _categoryRepo.GetAllCategories();
                _cboCategory.Items.Clear();
                _cboCategory.Items.Add(new Category(0, "All Categories"));
                foreach (var cat in categories) _cboCategory.Items.Add(cat);
                _cboCategory.SelectedIndex = 0;
                _suppressEvents = false;

                GenerateReport();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading report filters:\n{ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ReportMode_Changed(object? sender, EventArgs e)
        {
            _pnlDateFilters.Visible = _rbMovementReport.Checked;
            GenerateReport();
        }

        private void GenerateReport()
        {
            if (_suppressEvents) return;

            int categoryId = (_cboCategory.SelectedItem as Category)?.CategoryID ?? 0;

            _dgvReport.Rows.Clear();
            _dgvReport.Columns.Clear();

            if (_rbValuationReport.Checked)
            {
                List<Product> products = _productRepo.SearchProducts("", categoryId, "ALL");

                _dgvReport.Columns.Add(new DataGridViewTextBoxColumn { Name = "SKU", HeaderText = "SKU", FillWeight = 16 });
                _dgvReport.Columns.Add(new DataGridViewTextBoxColumn { Name = "ProductName", HeaderText = "Product Name", FillWeight = 30 });
                _dgvReport.Columns.Add(new DataGridViewTextBoxColumn { Name = "Category", HeaderText = "Category", FillWeight = 18 });
                _dgvReport.Columns.Add(new DataGridViewTextBoxColumn { Name = "Supplier", HeaderText = "Supplier", FillWeight = 18 });
                _dgvReport.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "UnitPrice",
                    HeaderText = "Price (₱)",
                    FillWeight = 13,
                    DefaultCellStyle = new DataGridViewCellStyle { Alignment = DataGridViewContentAlignment.MiddleRight }
                });
                _dgvReport.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "Qty",
                    HeaderText = "Stock",
                    FillWeight = 12,
                    DefaultCellStyle = new DataGridViewCellStyle { Alignment = DataGridViewContentAlignment.MiddleCenter, Font = UITheme.FontBold }
                });
                _dgvReport.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "TotalValue",
                    HeaderText = "Total Value (₱)",
                    FillWeight = 15,
                    DefaultCellStyle = new DataGridViewCellStyle { Alignment = DataGridViewContentAlignment.MiddleRight, Font = UITheme.FontBold }
                });
                _dgvReport.Columns.Add(new DataGridViewTextBoxColumn { Name = "Status", HeaderText = "Status", FillWeight = 16 });

                int totalUnits = 0;
                decimal grandTotalValue = 0M;

                foreach (var p in products)
                {
                    totalUnits += p.QuantityInStock;
                    grandTotalValue += p.TotalStockValue;

                    _dgvReport.Rows.Add(
                        p.SKU,
                        p.ProductName,
                        p.CategoryName,
                        p.SupplierName,
                        p.UnitPrice.ToString("N2"),
                        p.QuantityInStock,
                        p.TotalStockValue.ToString("N2"),
                        p.StockStatus);
                }

                _lblSummaryMetric1.Text = $"Products: {products.Count:N0}";
                _lblSummaryMetric2.Text = $"Total Units: {totalUnits:N0}";
                _lblSummaryMetric3.Text = $"Total Value: {UITheme.FormatCurrency(grandTotalValue)}";
            }
            else
            {
                string txType = _cboMovementType.SelectedItem?.ToString() ?? "ALL";
                List<StockTransaction> movements = _txRepo.GetTransactions(
                    _dtpFrom.Value,
                    _dtpTo.Value,
                    txType,
                    categoryId,
                    "",
                    1000);

                _dgvReport.Columns.Add(new DataGridViewTextBoxColumn { Name = "TxID", HeaderText = "ID", FillWeight = 9 });
                _dgvReport.Columns.Add(new DataGridViewTextBoxColumn { Name = "Date", HeaderText = "Date", FillWeight = 18 });
                _dgvReport.Columns.Add(new DataGridViewTextBoxColumn { Name = "Type", HeaderText = "Type", FillWeight = 12 });
                _dgvReport.Columns.Add(new DataGridViewTextBoxColumn { Name = "SKU", HeaderText = "SKU", FillWeight = 16 });
                _dgvReport.Columns.Add(new DataGridViewTextBoxColumn { Name = "Product", HeaderText = "Product Name", FillWeight = 28 });
                _dgvReport.Columns.Add(new DataGridViewTextBoxColumn { Name = "Category", HeaderText = "Category", FillWeight = 18 });
                _dgvReport.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "Qty",
                    HeaderText = "Qty",
                    FillWeight = 11,
                    DefaultCellStyle = new DataGridViewCellStyle { Alignment = DataGridViewContentAlignment.MiddleCenter }
                });
                _dgvReport.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "Before",
                    HeaderText = "Before",
                    FillWeight = 10,
                    DefaultCellStyle = new DataGridViewCellStyle { Alignment = DataGridViewContentAlignment.MiddleCenter }
                });
                _dgvReport.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "After",
                    HeaderText = "After",
                    FillWeight = 10,
                    DefaultCellStyle = new DataGridViewCellStyle { Alignment = DataGridViewContentAlignment.MiddleCenter, Font = UITheme.FontBold }
                });
                _dgvReport.Columns.Add(new DataGridViewTextBoxColumn { Name = "Ref", HeaderText = "Reference", FillWeight = 16 });
                _dgvReport.Columns.Add(new DataGridViewTextBoxColumn { Name = "Remarks", HeaderText = "Remarks", FillWeight = 24 });

                int totalIn = 0;
                int totalOut = 0;

                foreach (var tx in movements)
                {
                    if (tx.TransactionType == "IN") totalIn += tx.Quantity;
                    else totalOut += tx.Quantity;

                    string qtyFormatted = tx.TransactionType == "IN" ? $"+{tx.Quantity}" : $"-{tx.Quantity}";
                    _dgvReport.Rows.Add(
                        tx.TransactionID,
                        tx.TransactionDate.ToString("yyyy-MM-dd HH:mm"),
                        tx.TransactionType,
                        tx.SKU,
                        tx.ProductName,
                        tx.CategoryName,
                        qtyFormatted,
                        tx.PreviousStock,
                        tx.NewStock,
                        tx.ReferenceNo,
                        tx.Remarks);
                }

                _lblSummaryMetric1.Text = $"Transactions: {movements.Count:N0}";
                _lblSummaryMetric2.Text = $"Stock In: +{totalIn:N0}";
                _lblSummaryMetric3.Text = $"Stock Out: -{totalOut:N0}";
            }
        }

        private void BtnExportCsv_Click(object? sender, EventArgs e)
        {
            if (_dgvReport.Rows.Count == 0)
            {
                MessageBox.Show("No rows to export.", "Empty Report", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string defaultFileName = _rbValuationReport.Checked
                ? $"Stock_Valuation_{DateTime.Now:yyyyMMdd_HHmm}.csv"
                : $"Stock_Transactions_{DateTime.Now:yyyyMMdd_HHmm}.csv";

            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Title = "Export CSV";
                sfd.Filter = "CSV Files (*.csv)|*.csv";
                sfd.FileName = defaultFileName;

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        var sb = new StringBuilder();
                        var headers = new List<string>();
                        foreach (DataGridViewColumn col in _dgvReport.Columns)
                        {
                            if (col.Visible) headers.Add(EscapeCsv(col.HeaderText));
                        }
                        sb.AppendLine(string.Join(",", headers));

                        foreach (DataGridViewRow row in _dgvReport.Rows)
                        {
                            var cells = new List<string>();
                            foreach (DataGridViewColumn col in _dgvReport.Columns)
                            {
                                if (col.Visible)
                                {
                                    string val = row.Cells[col.Index].FormattedValue?.ToString() ?? string.Empty;
                                    cells.Add(EscapeCsv(val));
                                }
                            }
                            sb.AppendLine(string.Join(",", cells));
                        }

                        File.WriteAllText(sfd.FileName, sb.ToString(), Encoding.UTF8);
                        MessageBox.Show($"Saved to:\n{sfd.FileName}", "Export Complete",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Failed to export CSV:\n{ex.Message}", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private static string EscapeCsv(string value)
        {
            if (value.Contains(',') || value.Contains('"') || value.Contains('\n'))
                return $"\"{value.Replace("\"", "\"\"")}\"";
            return value;
        }

        private void DgvReport_CellPainting(object? sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex < 0) return;

            if (_dgvReport.Columns[e.ColumnIndex].Name == "Status" && e.Value != null)
            {
                UITheme.PaintStatusPillCell(e, e.Value.ToString());
            }
        }

        private void DgvReport_CellFormatting(object? sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex < 0) return;

            string colName = _dgvReport.Columns[e.ColumnIndex].Name;
            if ((colName == "Type" || colName == "Qty") && !_rbValuationReport.Checked && e.Value != null)
            {
                string val = e.Value.ToString() ?? string.Empty;
                var cell = _dgvReport.Rows[e.RowIndex].Cells[e.ColumnIndex];
                cell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                if (val == "IN" || val.StartsWith("+"))
                {
                    cell.Style.ForeColor = UITheme.TealGlow;
                    cell.Style.Font = UITheme.FontBold;
                }
                else if (val == "OUT" || val.StartsWith("-"))
                {
                    cell.Style.ForeColor = Color.FromArgb(251, 191, 36);
                    cell.Style.Font = UITheme.FontBold;
                }
            }
        }
    }
}
