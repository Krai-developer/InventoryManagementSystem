using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using InventoryManagementSystem.Models;

namespace InventoryManagementSystem.Database
{
    /// <summary>
    /// ADO.NET Repository for Category CRUD operations.
    /// </summary>
    public class CategoryRepository
    {
        /// <summary>
        /// Retrieves all categories along with the count of active products assigned to each category.
        /// </summary>
        public List<Category> GetAllCategories(string searchKeyword = "")
        {
            var categories = new List<Category>();

            string sql = @"
                SELECT 
                    c.CategoryID,
                    c.CategoryName,
                    ISNULL(c.Description, N'') AS Description,
                    c.CreatedAt,
                    COUNT(p.ProductID) AS ProductCount
                FROM dbo.Categories c
                LEFT JOIN dbo.Products p ON c.CategoryID = p.CategoryID AND p.IsActive = 1
                WHERE (@Keyword = N'' OR c.CategoryName LIKE @SearchPattern OR c.Description LIKE @SearchPattern)
                GROUP BY c.CategoryID, c.CategoryName, c.Description, c.CreatedAt
                ORDER BY c.CategoryName ASC;";

            using (SqlConnection conn = DbConnection.GetConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                string trimmed = (searchKeyword ?? string.Empty).Trim();
                cmd.Parameters.AddWithValue("@Keyword", trimmed);
                cmd.Parameters.AddWithValue("@SearchPattern", $"%{trimmed}%");

                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        categories.Add(new Category
                        {
                            CategoryID = reader.GetInt32(0),
                            CategoryName = reader.GetString(1),
                            Description = reader.GetString(2),
                            CreatedAt = reader.GetDateTime(3),
                            ProductCount = reader.GetInt32(4)
                        });
                    }
                }
            }

            return categories;
        }

        /// <summary>
        /// Inserts a new category into the database.
        /// </summary>
        public int AddCategory(Category category)
        {
            string sql = @"
                INSERT INTO dbo.Categories (CategoryName, Description, CreatedAt)
                VALUES (@CategoryName, @Description, GETDATE());
                SELECT CAST(SCOPE_IDENTITY() AS INT);";

            using (SqlConnection conn = DbConnection.GetConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@CategoryName", category.CategoryName.Trim());
                cmd.Parameters.AddWithValue("@Description", string.IsNullOrWhiteSpace(category.Description)
                    ? DBNull.Value
                    : category.Description.Trim());

                conn.Open();
                object? result = cmd.ExecuteScalar();
                return result != null ? Convert.ToInt32(result) : 0;
            }
        }

        /// <summary>
        /// Updates an existing category record.
        /// </summary>
        public bool UpdateCategory(Category category)
        {
            string sql = @"
                UPDATE dbo.Categories
                SET CategoryName = @CategoryName,
                    Description  = @Description
                WHERE CategoryID = @CategoryID;";

            using (SqlConnection conn = DbConnection.GetConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@CategoryID", category.CategoryID);
                cmd.Parameters.AddWithValue("@CategoryName", category.CategoryName.Trim());
                cmd.Parameters.AddWithValue("@Description", string.IsNullOrWhiteSpace(category.Description)
                    ? DBNull.Value
                    : category.Description.Trim());

                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        /// <summary>
        /// Returns the number of products currently referencing this category.
        /// </summary>
        public int GetAssignedProductCount(int categoryId)
        {
            string sql = "SELECT COUNT(*) FROM dbo.Products WHERE CategoryID = @CategoryID AND IsActive = 1;";

            using (SqlConnection conn = DbConnection.GetConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@CategoryID", categoryId);
                conn.Open();
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        /// <summary>
        /// Deletes a category if no products are assigned to it.
        /// </summary>
        public bool DeleteCategory(int categoryId, out string errorMessage)
        {
            errorMessage = string.Empty;

            int assignedProducts = GetAssignedProductCount(categoryId);
            if (assignedProducts > 0)
            {
                errorMessage = $"Cannot delete this category because {assignedProducts} product(s) are currently assigned to it. Please reassign or remove those products first.";
                return false;
            }

            try
            {
                string sql = "DELETE FROM dbo.Categories WHERE CategoryID = @CategoryID;";
                using (SqlConnection conn = DbConnection.GetConnection())
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@CategoryID", categoryId);
                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
            catch (SqlException ex)
            {
                errorMessage = $"Database constraint prevented deletion: {ex.Message}";
                return false;
            }
        }
    }
}
