using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using InventoryManagementSystem.Models;

namespace InventoryManagementSystem.Database
{
    /// <summary>
    /// ADO.NET Repository for Stock-In, Stock-Out, Dashboard KPIs, and Inventory Reports.
    /// Uses SqlTransaction to guarantee atomic stock adjustments and audit trail logging.
    /// </summary>
    public class StockTransactionRepository
    {
        /// <summary>
        /// Records a Stock-In ('IN') or Stock-Out ('OUT') movement inside an ACID SqlTransaction.
        /// Automatically updates Products.QuantityInStock and inserts a StockTransactions row.
        /// </summary>
        public bool RecordStockMovement(
            int productId,
            string transactionType,
            int quantity,
            string referenceNo,
            string remarks,
            out string message)
        {
            message = string.Empty;

            if (quantity <= 0)
            {
                message = "Quantity must be greater than zero.";
                return false;
            }

            string normalizedType = transactionType.Trim().ToUpperInvariant();
            if (normalizedType != "IN" && normalizedType != "OUT")
            {
                message = "Transaction type must be 'IN' or 'OUT'.";
                return false;
            }

            using (SqlConnection conn = DbConnection.GetConnection())
            {
                conn.Open();
                using (SqlTransaction tx = conn.BeginTransaction())
                {
                    try
                    {
                        // 1. Lock row and read current stock level
                        int currentStock;
                        string productName;
                        string selectSql = @"
                            SELECT QuantityInStock, ProductName
                            FROM dbo.Products WITH (UPDLOCK, ROWLOCK)
                            WHERE ProductID = @ProductID;";

                        using (SqlCommand selectCmd = new SqlCommand(selectSql, conn, tx))
                        {
                            selectCmd.Parameters.AddWithValue("@ProductID", productId);
                            using (SqlDataReader reader = selectCmd.ExecuteReader())
                            {
                                if (!reader.Read())
                                {
                                    tx.Rollback();
                                    message = "Selected product was not found in the database.";
                                    return false;
                                }

                                currentStock = reader.GetInt32(0);
                                productName = reader.GetString(1);
                            }
                        }

                        // 2. Validate Stock-Out quantity
                        if (normalizedType == "OUT" && quantity > currentStock)
                        {
                            tx.Rollback();
                            message = $"Insufficient stock for '{productName}'. Current available stock is {currentStock}, but {quantity} was requested.";
                            return false;
                        }

                        int newStock = normalizedType == "IN"
                            ? currentStock + quantity
                            : currentStock - quantity;

                        // 3. Update Products.QuantityInStock
                        string updateSql = @"
                            UPDATE dbo.Products
                            SET QuantityInStock = @NewStock
                            WHERE ProductID = @ProductID;";

                        using (SqlCommand updateCmd = new SqlCommand(updateSql, conn, tx))
                        {
                            updateCmd.Parameters.AddWithValue("@NewStock", newStock);
                            updateCmd.Parameters.AddWithValue("@ProductID", productId);
                            updateCmd.ExecuteNonQuery();
                        }

                        // 4. Insert audit record into StockTransactions
                        string insertSql = @"
                            INSERT INTO dbo.StockTransactions
                                (ProductID, TransactionType, Quantity, PreviousStock, NewStock, ReferenceNo, Remarks, TransactionDate)
                            VALUES
                                (@ProductID, @TransactionType, @Quantity, @PreviousStock, @NewStock, @ReferenceNo, @Remarks, GETDATE());";

                        using (SqlCommand insertCmd = new SqlCommand(insertSql, conn, tx))
                        {
                            insertCmd.Parameters.AddWithValue("@ProductID", productId);
                            insertCmd.Parameters.AddWithValue("@TransactionType", normalizedType);
                            insertCmd.Parameters.AddWithValue("@Quantity", quantity);
                            insertCmd.Parameters.AddWithValue("@PreviousStock", currentStock);
                            insertCmd.Parameters.AddWithValue("@NewStock", newStock);
                            insertCmd.Parameters.AddWithValue("@ReferenceNo", string.IsNullOrWhiteSpace(referenceNo)
                                ? DBNull.Value
                                : referenceNo.Trim());
                            insertCmd.Parameters.AddWithValue("@Remarks", string.IsNullOrWhiteSpace(remarks)
                                ? DBNull.Value
                                : remarks.Trim());

                            insertCmd.ExecuteNonQuery();
                        }

                        tx.Commit();
                        string actionVerb = normalizedType == "IN" ? "received into" : "issued from";
                        message = $"Successfully {actionVerb} stock! '{productName}' stock updated from {currentStock} to {newStock}.";
                        return true;
                    }
                    catch (Exception ex)
                    {
                        tx.Rollback();
                        message = $"Transaction failed: {ex.Message}";
                        return false;
                    }
                }
            }
        }

        /// <summary>
        /// Retrieves stock transaction history filtered by date range, type ('ALL', 'IN', 'OUT'), and search keyword.
        /// </summary>
        public List<StockTransaction> GetTransactions(
            DateTime? fromDate = null,
            DateTime? toDate = null,
            string transactionType = "ALL",
            int categoryId = 0,
            string searchKeyword = "",
            int maxRows = 500)
        {
            var list = new List<StockTransaction>();

            string sql = $@"
                SELECT TOP ({maxRows})
                    t.TransactionID,
                    t.ProductID,
                    p.SKU,
                    p.ProductName,
                    c.CategoryName,
                    t.TransactionType,
                    t.Quantity,
                    t.PreviousStock,
                    t.NewStock,
                    ISNULL(t.ReferenceNo, N'') AS ReferenceNo,
                    ISNULL(t.Remarks, N'') AS Remarks,
                    t.TransactionDate
                FROM dbo.StockTransactions t
                INNER JOIN dbo.Products p ON t.ProductID = p.ProductID
                INNER JOIN dbo.Categories c ON p.CategoryID = c.CategoryID
                WHERE (@Type = N'ALL' OR t.TransactionType = @Type)
                  AND (@CategoryID = 0 OR p.CategoryID = @CategoryID)
                  AND (@FromDate IS NULL OR t.TransactionDate >= @FromDate)
                  AND (@ToDate IS NULL OR t.TransactionDate < @ToDate)
                  AND (@Keyword = N'' 
                       OR p.SKU LIKE @Pattern 
                       OR p.ProductName LIKE @Pattern 
                       OR t.ReferenceNo LIKE @Pattern 
                       OR t.Remarks LIKE @Pattern)
                ORDER BY t.TransactionDate DESC, t.TransactionID DESC;";

            using (SqlConnection conn = DbConnection.GetConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                string trimmedKeyword = (searchKeyword ?? string.Empty).Trim();
                cmd.Parameters.AddWithValue("@Type", (transactionType ?? "ALL").ToUpperInvariant());
                cmd.Parameters.AddWithValue("@CategoryID", categoryId);
                cmd.Parameters.AddWithValue("@FromDate", fromDate.HasValue ? fromDate.Value.Date : DBNull.Value);
                cmd.Parameters.AddWithValue("@ToDate", toDate.HasValue ? toDate.Value.Date.AddDays(1) : DBNull.Value);
                cmd.Parameters.AddWithValue("@Keyword", trimmedKeyword);
                cmd.Parameters.AddWithValue("@Pattern", $"%{trimmedKeyword}%");

                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new StockTransaction
                        {
                            TransactionID = reader.GetInt32(0),
                            ProductID = reader.GetInt32(1),
                            SKU = reader.GetString(2),
                            ProductName = reader.GetString(3),
                            CategoryName = reader.GetString(4),
                            TransactionType = reader.GetString(5),
                            Quantity = reader.GetInt32(6),
                            PreviousStock = reader.GetInt32(7),
                            NewStock = reader.GetInt32(8),
                            ReferenceNo = reader.GetString(9),
                            Remarks = reader.GetString(10),
                            TransactionDate = reader.GetDateTime(11)
                        });
                    }
                }
            }

            return list;
        }

        /// <summary>
        /// Computes all Dashboard KPI summary values in a single database query.
        /// </summary>
        public DashboardSummary GetDashboardSummary()
        {
            var summary = new DashboardSummary();

            string sql = @"
                SELECT 
                    (SELECT COUNT(*) FROM dbo.Products WHERE IsActive = 1) AS TotalProducts,
                    (SELECT COUNT(*) FROM dbo.Categories) AS TotalCategories,
                    (SELECT ISNULL(SUM(QuantityInStock), 0) FROM dbo.Products WHERE IsActive = 1) AS TotalUnits,
                    (SELECT ISNULL(SUM(CAST(QuantityInStock AS DECIMAL(18,2)) * UnitPrice), 0) FROM dbo.Products WHERE IsActive = 1) AS TotalValue,
                    (SELECT COUNT(*) FROM dbo.Products WHERE IsActive = 1 AND QuantityInStock <= ReorderLevel) AS LowStockCount,
                    (SELECT COUNT(*) FROM dbo.Products WHERE IsActive = 1 AND QuantityInStock = 0) AS OutOfStockCount,
                    (SELECT COUNT(*) FROM dbo.StockTransactions WHERE TransactionDate >= CAST(GETDATE() AS DATE)) AS TodayTransactions;";

            using (SqlConnection conn = DbConnection.GetConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        summary.TotalProducts = reader.GetInt32(0);
                        summary.TotalCategories = reader.GetInt32(1);
                        summary.TotalUnitsInStock = reader.GetInt32(2);
                        summary.TotalInventoryValue = reader.GetDecimal(3);
                        summary.LowStockCount = reader.GetInt32(4);
                        summary.OutOfStockCount = reader.GetInt32(5);
                        summary.TodayTransactionsCount = reader.GetInt32(6);
                    }
                }
            }

            return summary;
        }
    }
}
